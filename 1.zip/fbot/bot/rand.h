#pragma once

void init_rand(void);
uint32_t rand_new(void);
void rand_string(uint8_t *, int);
