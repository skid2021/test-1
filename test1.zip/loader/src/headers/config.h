#pragma once

#define HTTP_SERVER "165.22.236.17"
#define HTTP_PORT 80

#define TFTP_SERVER "165.22.236.17"
